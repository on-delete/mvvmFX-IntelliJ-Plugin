import de.saxsys.mvvmfx.FxmlView;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class MainView implements FxmlView<MainViewModel>, Initializable {
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
