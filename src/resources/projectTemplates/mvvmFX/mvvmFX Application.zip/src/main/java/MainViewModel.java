import de.saxsys.mvvmfx.ViewModel;

public class MainViewModel implements ViewModel {
}
